package rc.udp;

public abstract class UDPNet {
	static final int receivePort = 8886;
}
