package rc.captain;

import rc.udp.UDPNet;
import android.os.Handler;
import android.util.Log;

public class CaptainImageReceiver extends Thread {
	CaptainMainActivity mainActivity;
	Handler mainHandler;
	UDPNet udp;
	byte[] receivemsg;
	
	public CaptainImageReceiver(CaptainMainActivity mainActivity) {
		this.mainActivity = mainActivity;
		this.mainHandler = mainActivity.mainHandler;
	}
	
	public void run(){
		try {
			// receive
			//receivemsg = udp.receive(1000);
			Log.d("bitmap", new String(receivemsg));
			// post
			
            for (int i = 0; i < 20; i++) {
                Thread.sleep(1000);
                 
                //mainHandler.post(runnable);
            }
        } catch (Exception ex) {
            Log.e("SampleThreadActivity", "Exception in processing message.", ex);
        }
	}
	/*
	public class ProgressRunnable implements Runnable {
		 
        public void run() {
 
            bar.incrementProgressBy(5);
 
            if (bar.getProgress() == bar.getMax()) {
                textView01.setText("Runnable Done");
            } else {
                textView01.setText("Runnable Working ..." + bar.getProgress());
            }
             
        }
         
    }
    */
}
