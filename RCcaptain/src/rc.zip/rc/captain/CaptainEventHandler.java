package rc.captain;

import rc.info.Direction;
import john.rccaptain.R;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.Toast;

public class CaptainEventHandler {
	CaptainMainActivity mainActivity;
	CaptainCommander commander;
	
	Button[] btnsAll;
	Button[] btnArrows;
	Button btnGravity, btnVoice, btnTracking;
	
	
	public CaptainEventHandler(CaptainMainActivity mainActivity) {
		this.mainActivity = mainActivity;
		
		inflate();
		setListeners();
	}
	
	private void inflate(){
		btnArrows = new Button[6];
		btnArrows[0] = (Button) mainActivity.findViewById(R.id.btnArrow_fLeft);
		btnArrows[1] = (Button) mainActivity.findViewById(R.id.btnArrow_front);
		btnArrows[2] = (Button) mainActivity.findViewById(R.id.btnArrow_fRight);
		btnArrows[3] = (Button) mainActivity.findViewById(R.id.btnArrow_bLeft);
		btnArrows[4] = (Button) mainActivity.findViewById(R.id.btnArrow_back);
		btnArrows[5] = (Button) mainActivity.findViewById(R.id.btnArrow_bRight);
		btnGravity = (Button) mainActivity.findViewById(R.id.btnGravity);
		btnVoice = (Button) mainActivity.findViewById(R.id.btnVoice);
		btnTracking = (Button) mainActivity.findViewById(R.id.btnTracking);
	}
	
	private void setListeners(){
		for(int i=0; i<6; i++){
			btnArrows[i].setOnTouchListener(new ArrowButtonTouchListener(i));
		}
		
		btnGravity.setOnTouchListener(new GravityButtonTouchListener());
	}
	
	private void enableOtherButtons(Button curButton,boolean enable){
		
	}
	
	class ArrowButtonTouchListener implements OnTouchListener{
		final byte direction;
		
		public ArrowButtonTouchListener(int direction) {
			super();
			this.direction = (byte)direction;
		}
		
		@Override
		public boolean onTouch(View v, MotionEvent event) {
			if(!mainActivity.checkIP()) return false;
			
			switch(event.getAction()){
		    case MotionEvent.ACTION_DOWN:
		    	((CaptainDirectionCommander) mainActivity.commander).direction = direction;
				return true;
			case MotionEvent.ACTION_UP:
				((CaptainDirectionCommander) mainActivity.commander).direction = Direction.STOP;
				return true;
		    }
			return false;
		}
	}
	
	class GravityButtonTouchListener implements OnTouchListener{
		@Override
		public boolean onTouch(View v, MotionEvent event) {
			if(!mainActivity.checkIP()) return false;
			
			switch(event.getAction()){
		    case MotionEvent.ACTION_DOWN:
		        Log.d("getAction","down");
		        break;

		    case MotionEvent.ACTION_UP:
		    	Log.d("getAction","up");
		        break;
		    }
			return false;
		}
		
	}
}
